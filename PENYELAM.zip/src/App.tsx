import { useEffect, useRef, useState } from 'react';
import { startAbyssalGarden, type EngineHandle, type HudState } from './game/engine';

let bootLock = false;

const CAM_NAMES = ['Standar', 'Megalophobia', 'POV / Kokpit'];
const FACE_MODES = ['Otomatis', 'Santai', 'Senang', 'Khawatir'];

export function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const barRef = useRef<HTMLElement | null>(null);
  const diveBtnRef = useRef<HTMLButtonElement | null>(null);
  const engineRef = useRef<EngineHandle | null>(null);
  const toastTimerRef = useRef<number>(0);
  const transitionTimerRef = useRef<number>(0);
  const frameReadyRef = useRef(false);
  const lastSeqRef = useRef<number>(0);
  const labelRefs = useRef<(HTMLDivElement | null)[]>([]);

  const [statusText, setStatusText] = useState('Menyiapkan ekspedisi...');
  const [browserHint, setBrowserHint] = useState(false);
  const [hasDived, setHasDived] = useState(false);
  const [gameReady, setGameReady] = useState(false);
  const [gameError, setGameError] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [diveTransition, setDiveTransition] = useState(false);
  const [awaitingFrame, setAwaitingFrame] = useState(false);
  const [revealingDive, setRevealingDive] = useState(false);
  const [detailLv, setDetailLv] = useState<number>(0);
  const [statsText, setStatsText] = useState('');
  const [toast, setToast] = useState('');
  const [hud, setHud] = useState<HudState>({
    inSub: false,
    miniMode: false,
    midnightMode: false,
    nearSub: true,
    subDist: 3.1,
    depth: 42,
    speed: 0,
    lightsOn: true,
    viewMode: 0,
    botsAboard: 0,
    summoning: false,
    mantaFlyby: false,
    mantaDist: 45,
    fishCount: 0,
    fishInventory: [0, 0, 0, 0, 0],
    harpoonPhase: 'ready',
    harpoonTargetVisible: false,
    harpoonTargetX: 0.5,
    harpoonTargetY: 0.5,
    harpoonRecoil: 0,
    toastEvent: '',
    toastSeq: 0,
  });

  const showToast = (msg: string, ms = 2800) => {
    setToast(msg);
    window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(''), ms);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || bootLock) return;
    bootLock = true;
    document.body.className = 'l';

    startAbyssalGarden(canvas, barRef.current, {
      onProgress: (msg) => setStatusText(msg),
      onBrowserHint: (show) => setBrowserHint(show),
      onError: (msg) => { setStatusText(msg); setGameError(msg); setGameReady(false); setDiveTransition(false); },
      onFirstFrame: () => {
        frameReadyRef.current = true;
        setAwaitingFrame(false);
        setRevealingDive(true);
        window.clearTimeout(transitionTimerRef.current);
        transitionTimerRef.current = window.setTimeout(() => setDiveTransition(false), 1550);
      },
      onMenuChange: (inMenu) => {
        if (inMenu) {
          window.setTimeout(() => diveBtnRef.current?.focus(), 100);
        } else {
          setHasDived(true);
          setSettingsOpen(false);
          (document.activeElement as HTMLElement | null)?.blur?.();
        }
      },
      onHud: (next) => {
        if (next.toastSeq !== lastSeqRef.current && next.toastEvent) {
          lastSeqRef.current = next.toastSeq;
          showToast(next.toastEvent, next.mantaFlyby ? 3800 : 2400);
        }
        setHud(next);
      },
      onStats: (s) => setStatsText(s),
      onViewpoint: (idx, name) => showToast(`${idx + 1} · ${name}`),
      onMute: (m) => showToast(m ? 'Suara Mati' : 'Suara Aktif', 1400),
    })
      .then((handle) => {
        engineRef.current = handle;
        setDetailLv(handle.level);
        setGameReady(true);
      })
      .catch((e: Error & { userFacing?: boolean }) => {
        console.error(e);
        document.body.className = 'l e';
        const gpuFailure = /external Instance|device lost|GPU|WebGPU/i.test(e.message);
        const message = gpuFailure && !e.userFacing
          ? 'WebGPU tidak dapat menampilkan adegan di perangkat ini. Coba Chrome atau Edge terbaru dengan akselerasi grafis aktif.'
          : (e.userFacing ? '' : 'Gagal memulai: ') + e.message;
        setStatusText(message);
        setGameError(message);
      });

    return () => {
      window.clearTimeout(toastTimerRef.current);
      window.clearTimeout(transitionTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!settingsOpen) return;
    const onEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSettingsOpen(false);
    };
    window.addEventListener('keydown', onEscape);
    return () => window.removeEventListener('keydown', onEscape);
  }, [settingsOpen]);

  // Crew name tags follow heads every frame (direct DOM writes, no React re-render)
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      raf = requestAnimationFrame(tick);
      const eng = engineRef.current;
      if (!eng || !eng.getLabels) return;
      const ls = eng.getLabels();
      for (const l of ls) {
        const el = labelRefs.current[l.i];
        if (!el) continue;
        if (!l.show || document.body.classList.contains('m')) { el.style.opacity = '0'; continue; }
        el.style.opacity = String(l.a);
        el.style.transform = `translate(${l.x.toFixed(1)}px, ${l.y.toFixed(1)}px) translate(-50%, -100%) scale(${(l.s ?? 1).toFixed(3)})`;
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const CREW_TAGS = [
    { name: 'Captain Ashford', role: 'Commander' },
    { name: 'Nathaniel', role: 'Co-Pilot' },
    { name: 'Beatrice', role: 'Navigator' },
    { name: 'Theodore', role: 'Harpooner' },
    { name: 'Eleanor', role: 'Marine Biologist' },
    { name: 'Percival', role: 'Engineer' },
  ];

  const handleDive = () => {
    if (!engineRef.current || diveTransition) return;
    setDiveTransition(true);
    setAwaitingFrame(!frameReadyRef.current);
    setRevealingDive(false);
    setSettingsOpen(false);
    setHasDived(true);
    // Enter immediately to retain the click's pointer-lock permission.
    engineRef.current.diveIn();
    window.clearTimeout(transitionTimerRef.current);
    if (frameReadyRef.current) transitionTimerRef.current = window.setTimeout(() => setDiveTransition(false), 2200);
  };

  const detailLabels = ['Low', 'Medium', 'High'];
  const camBadge = hud.viewMode === 1
    ? 'Megalophobia'
    : hud.viewMode === 3
      ? 'Luar Kapal 3D'
      : hud.viewMode === 2
        ? (hud.inSub ? (hud.inside === 'pilot' ? 'Mode POV Kemudi' : 'Mode POV Kabin') : 'POV Helm 1.4x')
        : (hud.inSub ? 'Kabin 3rd Person' : '3rd Person');

  return (
    <>
      <canvas id="c" ref={canvasRef} />

      {/* Minimal Diegetic In-Game HUD */}
      <div className="hud-layer">
        {/* Camera-specific subtle optical framing */}
        {hud.viewMode === 1 && <div className="mega-frame" />}
        {/* Helmet porthole, fisheye glass & cockpit glass are rendered in 3D/post-FX by the engine. */}

        {/* Harpoon reticle (diver only) */}
        {!hud.inSub && (
          <div className={`reticle ${hud.aimLock ? 'lock' : ''} ${hud.harpoonPhase !== 'ready' ? 'busy' : ''}`}
            style={{ transform: `translate(-50%, -50%) scale(${1 + hud.harpoonRecoil * 0.35})` }}>
            <i className="r-t" /><i className="r-b" /><i className="r-l" /><i className="r-r" /><b />
          </div>
        )}
        {!hud.inSub && hud.harpoonTargetVisible && (hud.harpoonPhase === 'tethered' || hud.harpoonPhase === 'reeling') && (
          <div className="spear-marker" style={{ left: `${hud.harpoonTargetX * 100}%`, top: `${hud.harpoonTargetY * 100}%` }} />
        )}

        {/* Harpoon status + fish inventory */}
        {!hud.inSub && (
          <div className="harpoon-panel">
            <div className={`hp-state hp-${hud.harpoonPhase}`}>
              <svg viewBox="0 0 64 20" className="hp-icon">
                <rect x="2" y="8" width="16" height="5" rx="2" fill="#6b3416" />
                <rect x="10" y="12" width="4" height="7" rx="1.5" fill="#5a2a10" />
                <rect x="17" y="8.6" width="30" height="3.6" rx="1.6" fill="#d9a24a" />
                {hud.harpoonPhase === 'ready' && <><rect x="12" y="6.2" width="44" height="1.4" fill="#cfd8de" /><path d="M56 4.8 L62 6.9 L56 9 Z" fill="#e6eef2" /></>}
                <circle cx="22" cy="15" r="3.4" fill="none" stroke="#d9a24a" strokeWidth="1.4" />
              </svg>
              <span>
                {hud.harpoonPhase === 'ready' && (hud.aimLock ? 'Ikan terkunci! Klik Kiri' : 'Harpoon siap · Klik Kiri')}
                {hud.harpoonPhase === 'flying' && 'Tombak meluncur…'}
                {hud.harpoonPhase === 'tethered' && 'Ikan tertancap! Klik Kanan tarik'}
                {hud.harpoonPhase === 'reeling' && 'Menggulung tali…'}
                {hud.harpoonPhase === 'miss' && 'Meleset · menarik tombak'}
              </span>
            </div>
            <div className="inv-row">
              {(hud.fishNames ?? ['Badut', 'Kupu-kupu', 'Singa', 'Tang Biru', 'Sarden']).map((n, i) => (
                <div key={n} className={`inv-slot k${i} ${hud.fishInventory[i] ? 'has' : ''}`} title={n}>
                  <svg viewBox="0 0 30 16"><path d="M3 8 Q11 0 21 4 L28 1 L26 8 L28 15 L21 12 Q11 16 3 8 Z" /><circle cx="8" cy="7" r="1.2" fill="#111" /></svg>
                  <b>{hud.fishInventory[i] ?? 0}</b>
                </div>
              ))}
            </div>
            <div className="inv-total">
              Inventori {hud.fishCount} ikan{hud.teamCount ? ` · Kru menangkap ${hud.teamCount}` : ''}
            </div>
          </div>
        )}

        {/* Elegant crew name tags */}
        <div className="name-tags">
          {CREW_TAGS.map((c, i) => (
            <div key={c.name} className="name-tag" ref={(el) => { labelRefs.current[i] = el; }} style={{ opacity: 0 }}>
              <span className="nt-name">{c.name}</span>
              <span className="nt-role">{c.role}</span>
            </div>
          ))}
        </div>

        {hud.megaActive && (hud.megaDist ?? 999) < 60 && (
          <div className="mega-warn">
            <b>MEGALODON</b>
            <span>{hud.megaPhase === 'observe' ? 'mengamati' : hud.megaPhase === 'leave' ? 'menjauh' : 'melintas'} · {hud.megaDist}m</span>
          </div>
        )}

        {toast && <div className="scenic-toast">{toast}</div>}

        {/* Contextual interaction prompt (airlock, helm, chairs, bunks, repair) */}
        {hud.interactLabel && !hud.proc && (
          <button type="button" className="board-prompt" onClick={() => engineRef.current?.toggleSubmarine()}>
            <i className="kbd kbd-brass">F</i>
            <span>{hud.interactLabel}</span>
          </button>
        )}

        {/* Airlock procedure: fade to black + professional checklist */}
        {(hud.fade ?? 0) > 0.01 && <div className="airlock-fade" style={{ opacity: hud.fade }} />}
        {hud.proc && (
          <div className="airlock-panel">
            <div className="al-title">{hud.proc.kind === 'enter' ? 'PROSEDUR MASUK · AIRLOCK' : 'PROSEDUR KELUAR · AIRLOCK'}</div>
            {hud.proc.steps.map((st, i) => (
              <div key={st} className={`al-step ${i < hud.proc!.idx ? 'done' : i === hud.proc!.idx ? 'now' : ''}`}>
                <b>{i < hud.proc!.idx ? '✔' : i === hud.proc!.idx ? '▶' : '○'}</b>
                <span>{st}</span>
                {i === hud.proc!.idx && <i className="al-bar"><em style={{ width: `${hud.proc!.progress * 100}%` }} /></i>}
              </div>
            ))}
          </div>
        )}

        {/* Hull integrity */}
        {(hud.inSub || (hud.hull ?? 100) < 100) && (
          <div className={`hull-meter ${(hud.hull ?? 100) < 30 ? 'crit' : ''}`}>
            <span>LAMBUNG</span>
            <i><em style={{ width: `${hud.hull ?? 100}%` }} /></i>
            <b>{hud.hull ?? 100}%</b>
            {hud.repairing && <small>memperbaiki…</small>}
          </div>
        )}

        {/* Compact bottom-left status capsule */}
        {hud.inSub ? (
          <div className="crew-pill sub-mode">
            <span className={hud.viewMode === 1 ? 'crew-dot mega' : 'crew-dot'} />
            <span>Kapal Selam · Kru {1 + hud.botsAboard}/6 · Helm di Rak</span>
            <span className="mini-badge">{hud.inside === 'walk' ? 'Jalan Bebas' : 'Berdiri di Kemudi'}</span>
            {hud.miniMode && <span className="mini-badge">Mungil -60%</span>}
            <span className="pill-sep">·</span>
            <span>-{hud.depth}m · {(hud.speed * 1.94).toFixed(0)} kt</span>
            <span className="pill-sep">·</span>
            <span>{camBadge}</span>
            <span className="pill-sep pill-hint">·</span>
            <span className="pill-hint" onClick={() => engineRef.current?.toggleCockpit()} style={{ cursor: 'pointer' }}>
              <i className="kbd kbd-cyan">K</i> {hud.viewMode === 2 ? 'Kembali 3rd Person' : 'Opsi POV'}
            </span>
            <span className="pill-hint" onClick={() => engineRef.current?.cycleView()} style={{ cursor: 'pointer' }}>
              <i className="kbd">V</i> Kamera
            </span>
            <span className="pill-hint"><i className="kbd">J</i> Megalo</span>
            <span className="pill-hint"><i className="kbd">B</i> Megalodon</span>
            <span className="pill-hint"><i className="kbd kbd-brass">G</i> -60%</span>
            <span className="pill-hint"><i className="kbd">C</i> Manta 10x</span>
            <span className="pill-hint"><i className="kbd">N</i> {hud.midnightMode ? 'Siang' : 'Midnight'}</span>
            <span className="pill-hint"><i className="kbd kbd-brass">F</i> {hud.inside === 'walk' ? 'Interaksi' : 'Lepas Kemudi'}</span>
          </div>
        ) : (
          <div className="crew-pill">
            <span className={hud.viewMode === 1 ? 'crew-dot mega' : 'crew-dot'} />
            <span>Kru 6 Penyelam · Helm 1.4x</span>
            {hud.midnightMode && <span className="mini-badge night">Midnight</span>}
            {hud.miniMode && <span className="mini-badge">Mungil -60%</span>}
            <span className="pill-sep">·</span>
            <span>-{hud.depth}m</span>
            <span className="pill-sep">·</span>
            <span>{camBadge}</span>
            <span className="pill-sep pill-hint">·</span>
            <span className="pill-hint"><i className="kbd kbd-brass">G</i> -60%</span>
            <span className="pill-hint"><i className="kbd">J</i> Megalo</span>
            <span className="pill-hint"><i className="kbd kbd-cyan">K</i> POV</span>
            <span className="pill-hint"><i className="kbd">B</i> Megalodon</span>
            <span className="pill-hint"><i className="kbd">N</i> {hud.midnightMode ? 'Siang' : 'Midnight'}</span>
            {hud.subDist > 8 && (
              <span className="pill-hint">
                <i className="kbd kbd-brass">R</i> {hud.summoning ? 'Datang…' : `Kapal (${Math.round(hud.subDist)}m)`}
              </span>
            )}
          </div>
        )}

        {/* Touch action buttons for mobile/tablet */}
        <div className="touch-bar">
          <button
            type="button"
            className="touch-btn gold"
            onClick={() => engineRef.current?.toggleSubmarine()}
          >
            {hud.inSub ? (hud.inside === 'pilot' ? 'Lepas Kemudi (F)' : 'Interaksi (F)') : (hud.hatchDist ?? 99) < 14 ? 'Airlock (F)' : 'Panggil Kapal'}
          </button>
          <button
            type="button"
            className={`touch-btn ${hud.viewMode === 2 ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleCockpit()}
          >
            {hud.inSub ? (hud.viewMode === 2 ? '3rd Person' : 'Opsi POV (K)') : 'POV'}
          </button>
          {hud.inSub && (
            <button
              type="button"
              className="touch-btn"
              onClick={() => engineRef.current?.cycleView()}
            >
              Kamera (V)
            </button>
          )}
          <button
            type="button"
            className={`touch-btn ${hud.viewMode === 1 ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMegalophobia()}
          >
            Megalo
          </button>
          <button
            type="button"
            className={`touch-btn gold ${hud.miniMode ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMiniMode()}
          >
            -60%
          </button>
          <button
            type="button"
            className="touch-btn"
            onClick={() => engineRef.current?.toggleLights()}
          >
            Lampu
          </button>
          <button
            type="button"
            className={`touch-btn ${hud.midnightMode ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMidnight()}
          >
            Midnight
          </button>
          <button type="button" className="touch-btn" onClick={() => engineRef.current?.spawnMegalodon()}>Megalodon</button>
          {!hud.inSub && (
            <>
              <button type="button" className="touch-btn gold" onClick={() => engineRef.current?.fireHarpoon()}>Tembak</button>
              <button type="button" className="touch-btn" onClick={() => engineRef.current?.reelHarpoon()}>Tarik</button>
            </>
          )}
        </div>
      </div>

      <div id="m">
        <div className="menu-art" aria-hidden="true" />
        <div className="menu-shade" aria-hidden="true" />

        <header className="menu-top">
          <div className="menu-monogram" aria-label="Abyssal Garden"><span>A</span><span>G</span></div>
          <button type="button" className="menu-settings-trigger" onClick={() => setSettingsOpen(true)}>
            Pengaturan &amp; kontrol <span aria-hidden="true">+</span>
          </button>
        </header>

        <main className="menu-main">
          <div className="menu-copy">
            <p className="menu-eyebrow">SEBUAH EKSPEDISI BAWAH LAUT</p>
            <h1>ABYSSAL <em>GARDEN</em></h1>
            <p className="menu-description">Ikuti jalur pasir di bawah lengkung batu, dari taman karang yang diterangi matahari hingga ke laut dalam.</p>
            <div id="a">
              <div id="g" className="menu-actions">
                <button id="d" ref={diveBtnRef} className="ag-btn" type="button" onClick={handleDive} disabled={!gameReady}>
                  <span>{hasDived ? 'LANJUTKAN PENYELAMAN' : 'MULAI MENYELAM'}</span>
                  <span className="cta-arrow" aria-hidden="true">↗</span>
                </button>
                <button type="button" className="menu-learn" onClick={() => setSettingsOpen(true)}>Cara bermain <span aria-hidden="true">↗</span></button>
              </div>
              {!gameReady && (
                <div id="l" className={gameError ? 'menu-status error' : 'menu-status'} role="status">
                  {!gameError && <div id="p"><i id="b" ref={barRef} /></div>}
                  <p id="s">{statusText}</p>
                  {browserHint && !gameError && <p id="w">Chrome atau Edge direkomendasikan untuk WebGPU.</p>}
                </div>
              )}
            </div>
          </div>
        </main>

        {settingsOpen && (
          <div className="settings-overlay">
            <button className="settings-scrim" type="button" aria-label="Tutup pengaturan" onClick={() => setSettingsOpen(false)} />
            <aside className="settings-panel" role="dialog" aria-modal="true" aria-label="Pengaturan dan kontrol">
              <div className="settings-head">
                <div><small>ABYSSAL GARDEN</small><h2>Siapkan penyelaman</h2></div>
                <button type="button" className="settings-close" aria-label="Tutup pengaturan" onClick={() => setSettingsOpen(false)} autoFocus>×</button>
              </div>
              <p className="settings-intro">Mulai di Coral Garden, sekitar 30 meter. Ikuti jalur pasir di bawah lengkung batu untuk memasuki ngarai; lokasi lama tetap bisa dikunjungi.</p>

              <div className="settings-section">
                <h3>Tampilan</h3>
                <div className="opt-row"><span>Ukuran</span><div className="setting-options">
                  <button type="button" className={!hud.miniMode ? 'on' : ''} onClick={() => engineRef.current?.toggleMiniMode(false)}>Standar</button>
                  <button type="button" className={hud.miniMode ? 'on' : ''} onClick={() => engineRef.current?.toggleMiniMode(true)}>Mungil -60%</button>
                </div></div>
                <div className="opt-row"><span>Kamera</span><div className="setting-options">
                  {CAM_NAMES.map((name, idx) => <button key={name} type="button" className={hud.viewMode === idx ? 'on' : ''} onClick={() => engineRef.current?.setViewMode(idx)}>{name}</button>)}
                </div></div>
                <div className="opt-row"><span>Waktu</span><div className="setting-options">
                  <button type="button" className={!hud.midnightMode ? 'on' : ''} onClick={() => engineRef.current?.toggleMidnight(false)}>Siang</button>
                  <button type="button" className={hud.midnightMode ? 'on' : ''} onClick={() => engineRef.current?.toggleMidnight(true)}>Midnight</button>
                </div></div>
                <div className="opt-row"><span>Ekspresi kru</span><div className="setting-options">
                  {FACE_MODES.map((label, i) => <button key={label} type="button" className={(hud.faceMode ?? 0) === i ? 'on' : ''} aria-pressed={(hud.faceMode ?? 0) === i} disabled={!gameReady} onClick={() => engineRef.current?.setFaceMode(i)}>{label}</button>)}
                </div></div>
                <div className="opt-row"><span>Detail</span><div className="setting-options">
                  {detailLabels.map((label, i) => { const lv = 2 - i; return <button key={label} type="button" className={lv === detailLv ? 'on' : ''} onClick={() => engineRef.current?.setDetail(lv)}>{label}</button>; })}
                </div></div>
              </div>

              <div className="settings-section controls-section">
                <h3>Kontrol</h3>
                <div id="k">
                  <p><i><b>W A S D</b></i><span>Renang / kemudi</span><i><b>Q / E</b></i><span>Turun / naik</span><i><b>SHIFT</b></i><span>Bergerak cepat</span><i><b>F</b></i><span>Airlock / interaksi</span><i><b>R / L</b></i><span>Panggil kapal / lampu</span></p>
                  <p><i><b>K / V</b></i><span>POV / ganti kamera</span><i><b>J / B</b></i><span>Megalo / hiu</span><i><b>N</b></i><span>Mode midnight</span><i><b>1 - 7</b></i><span>Pilih lokasi</span><i><b>KLIK</b></i><span>Harpoon / tarik tali</span></p>
                </div>
                <p id="h">Sentuh dan geser untuk berenang atau berbelok. Dua jari untuk bergerak lebih cepat.</p>
              </div>
              <div className="settings-foot"><span>Memerlukan browser dengan dukungan WebGPU.</span><a href="https://github.com/akuamirkap-cyber/w" target="_blank" rel="noreferrer">Sumber proyek ↗</a></div>
            </aside>
          </div>
        )}
      </div>

      {diveTransition && <div className={`dive-transition${awaitingFrame ? ' waiting' : revealingDive ? ' revealing' : ''}`} aria-hidden="true"><div className="dive-bubbles">{Array.from({ length: 12 }, (_, i) => <i key={i} />)}</div>{awaitingFrame && <span className="dive-prepare">Membuka pandangan...</span>}</div>}

      <button
        id="o"
        className="ag-btn"
        type="button"
        aria-label="Menu"
        onClick={() => engineRef.current?.openMenu()}
      >
        ≡
      </button>
      <pre id="i">{statsText}</pre>
    </>
  );
}

export default App;
